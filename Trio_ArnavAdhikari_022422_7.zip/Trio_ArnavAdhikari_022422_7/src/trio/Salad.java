package trio;

public class Salad extends SimpleLunchItem
{
	public Salad(String name, double price)
	{ super(name, price); }
}