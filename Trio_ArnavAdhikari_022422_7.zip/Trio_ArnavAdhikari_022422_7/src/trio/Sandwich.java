package trio;

public class Sandwich extends SimpleLunchItem
{
	public Sandwich(String name, double price)
	{ super(name, price); }
}