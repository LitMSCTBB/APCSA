package trio;

public class Drink extends SimpleLunchItem
{
	public Drink(String name, double price)
	{ super(name, price); }
}
