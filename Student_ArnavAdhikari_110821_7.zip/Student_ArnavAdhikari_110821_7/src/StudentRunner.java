
public class StudentRunner {
	public static void main(String[] args) {
      Student s1 = new Student("Skyler", "skyler@sky.com", 123456);
      Student s2 = new Student("Armand", "ARAMONES@houstonisd.org", 1108581);
      Student s3 = new Student("Jay", "S1699154@online.houstonisd.org", 1699154);
      System.out.println(s1); System.out.println(s2); System.out.println(s3);
   }
}
