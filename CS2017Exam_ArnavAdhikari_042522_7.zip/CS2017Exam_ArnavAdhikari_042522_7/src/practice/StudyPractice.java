package practice;

public interface StudyPractice {
	String getProblem();
	void nextProblem();
}
